import sys
from collections import defaultdict
 
INF = 10**18
 
class ScoreResult:
    def __init__(self, score, target):
        self.score = score
        self.target = target
 
def get_score(N, M, C):
    global encounters, left, right
    res = ScoreResult(-1, -1)
    for i in range(M):
        encounters[i] = -1
    
    for i in range(N):
        left[i] = encounters[C[i]]
        right[i] = -1
        encounters[C[i]] = i
        if left[i] != -1:
            right[left[i]] = i
    
    for i in range(N):
        lcl_left = INF if left[i] == -1 else i - left[i]
        lcl_right = INF if right[i] == -1 else right[i] - i
 
        lcl = min(lcl_left, lcl_right)
        if (lcl <= res.score): continue
 
        res = ScoreResult( lcl, i )
 
    return res
 
def get_score_morph(N, M, C, x, y):
    targets = []
 
    for i in range(N):
        if C[i] == x:
            C[i] = y
            targets.append(i)
 
    res = get_score(N, M, C).score
 
    for u in targets:
        C[u] = x
    
    return res
 
def show(x):
    if x == INF:
        x = -1
    print(x)
 
def solve():
    N, M = map(int, sys.stdin.readline().split())
    global encounters, left, right
    encounters = [-1 for _ in range(M)]
    left = [-1 for _ in range(N)]
    right = [-1 for _ in range(N)]
 
    C = list(map(int, sys.stdin.readline().split()))
    C = [c - 1 for c in C]
 
    ini = get_score(N, M, C)
    res = ini.score
    c2  = C[ini.target]
    
    for c1 in range(M):
        res = min(res, get_score_morph(N, M, C, c1, c2))
 
 
    show(res)
 
def main():
    T = 1
    MULTITEST = False
    if MULTITEST:
        T = int(sys.stdin.readline())
 
    for _ in range(T):
        solve()
 
if __name__ == "__main__":
    main()
