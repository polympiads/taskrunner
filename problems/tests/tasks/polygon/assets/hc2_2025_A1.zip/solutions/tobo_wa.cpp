#include <bits/stdc++.h>
using namespace std;
using i64 = long long;


int main() {
    cin.tie(nullptr)->sync_with_stdio(false);

    int n, m;
    cin >> n >> m;
    vector<int> a(n + 1);
    vector<vector<int>> pos(m + 1);
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        pos[a[i]].push_back(i);
    }
    vector<int> cost(m + 1), alone;
    int sum = 0;
    for (int i = 1; i <= m; i++) {
        if (pos[i].empty()) continue;
        if (pos[i].size() == 1) {
            alone.push_back(i);
            continue;
        }
        cost[i] = max(pos[i][1] - pos[i][0], pos[i].end()[-1] - pos[i].end()[-2]);
        for (int j = 1; j + 1 < pos[i].size(); j++) {
            cost[i] = max(cost[i], min(pos[i][j] - pos[i][j - 1], pos[i][j + 1] - pos[i][j]));
        }
        sum = max(sum, cost[i]);
    }
    auto suf = cost;
    for (int i = m - 1; i >= 1; i--) {
        suf[i] = max(suf[i + 1], suf[i]);
    }
    suf.push_back(0);
    if (alone.size() > 2) {
        cout << -1 << '\n';
        exit(0);
    }
    if (alone.size() == 2) {
        int ans = max(sum, abs(pos[alone[0]][0] - pos[alone[1]][0]));
        cout << ans << '\n';
        exit(0);
    }
    if (alone.size() == 1) {
        int u = alone[0];
        int ans = 1e9;
        for (int i = 1, pre = 0; i <= m; i++) {
            if (pos[i].size() < 2) continue;
            int tmp = 0;
            pos[i].push_back(pos[u][0]);
            sort(pos[i].begin(), pos[i].end());
            tmp = max(pos[i][1] - pos[i][0], pos[i].end()[-1] - pos[i].end()[-2]);
            for (int j = 1; j + 1 < pos[i].size(); j++) {
                tmp = max(tmp, min(pos[i][j] - pos[i][j - 1], pos[i][j + 1] - pos[i][j]));
            }
            ans = min(ans, max({pre, suf[i + 1], tmp}));
            pre = max(pre, cost[i]);
        }
        cout << ans << '\n';
        exit(0);
    }
    int ans = 1e9;
    for (int i = 1, pre = 0; i <= m; i++) {
        if (pos[i].empty()) continue;
        for (int j = i + 1, x = 0, y = 0, pre1 = 0; j <= m; j++) {
            if (pos[j].empty()) continue;
            int tmp = 0;
            while (x < pos[i].size() and y < pos[j].size()) {
                int cur = 1e9;
                if (pos[i][x] < pos[j][y]) {
                    if (x) cur = min(cur, pos[i][x] - pos[i][x - 1]);
                    if (x + 1 < pos[i].size()) cur = min(cur, pos[i][x + 1] - pos[i][x]);
                    cur = min(cur, pos[j][y] - pos[i][x]);
                    if (y) cur = min(cur, pos[i][x] - pos[j][y - 1]);
                    x++;
                } else {
                    if (y) cur = min(cur, pos[j][y] - pos[j][y - 1]);
                    if (y + 1 < pos[j].size()) cur = min(cur, pos[j][y + 1] - pos[j][y]);
                    cur = min(cur,  pos[i][x] - pos[j][y]);
                    if (x) cur = min(cur,  pos[j][y] - pos[i][x - 1]);
                    y++;
                }
                tmp = max(tmp, cur);
            }
            ans = min(ans, max({pre, pre1, suf[j + 1], tmp}));
            pre1 = max(pre1, cost[j]);
        }
        pre = max(pre, cost[i]);
    }
    cout << ans << '\n';
}   
/*

 */