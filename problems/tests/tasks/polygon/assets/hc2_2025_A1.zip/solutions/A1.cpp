#include <bits/stdc++.h>
#define int long long
 
#define MULTITEST false
 
const int INF = 1e18;
 
using namespace std;
 
struct ScoreResult {
    int score;
    int target;
};
 
ScoreResult get_score (int N, vector<int> &C) {
    ScoreResult res = { -1, -1 };
    for (int i = 0; i < N; i ++) {
        int lcl = INF;
        for (int j = 0; j < N; j ++) {
            if (i == j) continue ;
            if (C[i] != C[j]) continue ;
        
            lcl = min(lcl, abs(j - i));
        }
 
        if (res.score < lcl) res = { lcl, i };
    }
 
    return res;
}
int get_score_morph (int N, vector<int> &C, int x, int y) {
    vector<int> targets;
 
    for (int i = 0; i < N; i ++) {
        if (C[i] == x) {
            C[i] = y;
            targets.push_back(i);
        }
    }
 
    int res = get_score(N, C).score;
 
    for (int u : targets)
        C[u] = x;
    
    return res;
}
 
void show (int x) {
    if (x == INF) x = -1;
    cout << x << "\n";
}
void solve () {
    int N, M;
    cin >> N >> M;
 
    vector<int> C(N);
    for (int i = 0; i < N; i ++) {
        cin >> C[i];
        C[i] --;
    }
 
    int res = get_score(N, C).score;
    for (int c1 = 0; c1 < M; c1 ++) {
        for (int c2 = c1 + 1; c2 < M; c2 ++) {
            res = min(res, get_score_morph(N, C, c1, c2));
        }
    }
 
    show(res);
}
 
signed main () {
    ios_base::sync_with_stdio(false); cin.tie(NULL);
 
    int T = 1;
    if (MULTITEST) cin >> T;
 
    for (int t = 0; t < T; t ++) solve();
}
