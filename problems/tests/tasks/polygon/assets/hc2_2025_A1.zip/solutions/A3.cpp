#include <bits/stdc++.h>
#define int long long
 
#define MULTITEST false
 
const int INF = 1e18;
 
using namespace std;
 
struct ScoreResult {
    int score;
    int target;
};
 
ScoreResult get_score (int N, int M, vector<int> &C) {
    ScoreResult res = { -1, -1 };
    
    vector<vector<int>> encounters(M);
    for (int i = 0; i < N; i ++)
        encounters[C[i]].push_back(i);
    
    for (int i = 0; i < M; i ++) {
        for (int j = 0; j < encounters[i].size(); j ++) {
            int lcl_left  = j == 0 ? INF : encounters[i][j] - encounters[i][j - 1];
            int lcl_right = j == encounters[i].size() - 1
                 ? INF : encounters[i][j + 1] - encounters[i][j];
            
            int lcl = min(lcl_left, lcl_right);
            if (lcl <= res.score) continue ;
 
            res = { lcl, encounters[i][j] };
        }
    }
 
    return res;
}
int get_score_morph (int N, int M, vector<int> &C, int x, int y) {
    vector<int> targets;
 
    for (int i = 0; i < N; i ++) {
        if (C[i] == x) {
            C[i] = y;
            targets.push_back(i);
        }
    }
 
    int res = get_score(N, M, C).score;
 
    for (int u : targets)
        C[u] = x;
    
    return res;
}
 
void show (int x) {
    if (x == INF) x = -1;
    cout << x << "\n";
}
void solve () {
    int N, M;
    cin >> N >> M;
 
    vector<int> C(N);
    for (int i = 0; i < N; i ++) {
        cin >> C[i];
        C[i] --;
    }
 
    ScoreResult initial = get_score(N, M, C);
 
    int res = INF;
    int c2 = C[initial.target];
 
    for (int c1 = 0; c1 < M; c1 ++) {
        res = min(res, get_score_morph(N, M, C, c1, c2));
    }
 
    show(res);
}
 
signed main () {
    ios_base::sync_with_stdio(false); cin.tie(NULL);
 
    int T = 1;
    if (MULTITEST) cin >> T;
 
    for (int t = 0; t < T; t ++) solve();
}
