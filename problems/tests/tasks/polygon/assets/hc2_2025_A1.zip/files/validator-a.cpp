#include <bits/stdc++.h>
#include "testlib.h"

#define MAXN 100
#define MAXM 10

using namespace std;
signed main (int argc, char* argv[]) {
    registerValidation(argc, argv);

    int N = inf.readInt(1, MAXN, "N");
    inf.readSpace();
    int M = inf.readInt(1, MAXM, "M");
    inf.readEoln();

    vector<int> C(N);
    for (int i = 0; i < N; i ++) {
        C[i] = inf.readInt(1, M, "C_i");

        if (i == N - 1) inf.readEoln();
        else inf.readSpace();
    }

    inf.readEof();
}