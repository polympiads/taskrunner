#include <bits/stdc++.h>
#include "testlib.h"

using namespace std;

void show (int N, int M, vector<int> A) {
    cout << N << " " << M << "\n";
    bool first = true;
    for (int & a : A) {
        if (!first) cout << " ";
        cout << a;
        first = false;
    }
    cout << "\n";
}

signed main (int argc, char* argv[]) {
    registerGen(argc, argv, 1);

    int N = opt<int>(1);
    int M = opt<int>(2);

    vector<int> A(N);
    for (int i = 0; i < N; i ++)
        A[i] = rnd.next(1, M);
    
    show(N, M, A);
}