#include <bits/stdc++.h>
#include "testlib.h"

using namespace std;

void show (int N, int M, vector<int> A) {
    cout << N << " " << M << "\n";
    bool first = true;
    for (int & a : A) {
        if (!first) cout << " ";
        cout << a;
        first = false;
    }
    cout << "\n";
}

signed main (int argc, char* argv[]) {
    registerGen(argc, argv, 1);

    int N = opt<int>(1);
    int M = opt<int>(2);

    vector<int> R;
    R.push_back(1);
    if (M != 1) R.push_back(2);
    for (int i = 2; i < M; i ++) {
        R.push_back(1 + i);
        R.push_back(1 + i);
    }

    vector<int> A(N);
    for (int i = 0; i < N; i ++) {
        A[i] = R[i % R.size()];
    }
    
    show(N, M, A);
}