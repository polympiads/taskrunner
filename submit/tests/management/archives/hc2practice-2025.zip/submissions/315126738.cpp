#include <vector>
#include <stdio.h>

int main() {
	int a, b;
	scanf("%d %d\n", &a, &b);
	printf("%d", a+b);
	std::vector<int> v;
}
