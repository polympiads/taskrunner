#include <bits/stdc++.h>

using namespace std;

int main()
{
    vector <int> vec;
    int n;
    cin >> n;
    for(int i = 0 ; i<n ; i++)
    {
        int temp;
        cin >> temp;
        vec.push_back(temp);
    }
    sort(vec.begin(), vec.end());
        for(int i = 0 ; i<n ; i++)
    {
        cout << vec[i] << " ";
    }
    return 0;
}