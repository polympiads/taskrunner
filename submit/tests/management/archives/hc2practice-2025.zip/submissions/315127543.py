import sys
input = sys.stdin.readline
sys.setrecursionlimit(1000000)

a, b = [int(val) for val in input().split(" ")]
print(a + b)

