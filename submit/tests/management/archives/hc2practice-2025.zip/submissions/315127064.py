import sys

input = sys.stdin.readline

args = list(map(int, input().split()))

print(args[0] + args[1])