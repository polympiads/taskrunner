import sys

inp = sys.stdin.readline()
a,b = inp.split()
print(int(a)+int(b))
