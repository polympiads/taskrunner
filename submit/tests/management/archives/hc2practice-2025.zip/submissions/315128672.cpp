#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
using namespace std;

#define ll long long
using namespace __gnu_pbds;
template<class T> using Tree = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
ll n;
const ll MAXN = 1e5;
ll a[MAXN];
typedef pair<ll, ll> pll;
int main() {
    cin >> n;
    Tree<pll> s;
    for (int i = 0; i < n; i++) {
        cin >> a[i];
        s.insert({a[i], i});
    }
    for (int i = 0; i < n; i++) {
        cout << (*(s.find_by_order(i))).first << " \n"[i+1==n];
    }

    
}