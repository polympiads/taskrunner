#include <bits/stdc++.h>
#define ll long long int

int main() {

    std::ios::sync_with_stdio(0);
    std::cin.tie(0);

    int a,b;
    std::cin >> a >> b;

    std::cout << a+b << "\n";



    return 0;
}