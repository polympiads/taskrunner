#include <bits/stdc++.h>

#define int long long

signed main() {
    
    int a,b;
    cin >> a >> b;
    cout << a + b;
}