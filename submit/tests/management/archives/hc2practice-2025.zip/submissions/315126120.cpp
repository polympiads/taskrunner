#include <vector>

using namespace std;
vector<int> buf = {};
int global=1;
extern "C"{
    #include <stdio.h>

    int main(void)
    {
        buf.push_back(2);
        int a, b;
        scanf("%d", &a);
        scanf("%d",  &b);
        printf("%d\n", a+b);
    }
}