import sys
input = sys.stdin.readline
sys.setrecursionlimit(100000)

a, b = list(map(int, input().strip().split()))
print(a + b)


