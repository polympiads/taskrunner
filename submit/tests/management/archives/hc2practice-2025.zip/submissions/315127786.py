import sys

input = sys.stdin.readline

n = int(input())
l = list(map(int, input().split()))
l.sort()
sys.stdout.write(" ".join(map(str, l)) + "\n")

