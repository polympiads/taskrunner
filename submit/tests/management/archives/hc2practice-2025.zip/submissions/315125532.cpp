#include <iostream>

int main(int argc, char *argv[]) {
    
    int a, b;
    std::cin >> a >> b;
    
    std::cout << a + b << std::endl;
    
}