# def main():
        
print("Sucess")

import sys
input = sys.stdin.readline
sys.setrecursionlimit(10000000)

# Read 1 int
n = int(input().strip())

# Read one word on a line
word = input().strip()

# Read all the integers on a line
a = list(map (int, input().strip().split()))

# a, b = list(map int, input().strip().split())

# a, b = list(input().strip().split())

print(n)



# if __name__ == '__main__':
#    main()