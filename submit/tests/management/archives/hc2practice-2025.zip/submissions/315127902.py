


N = int(input())
nums = input().split()
nums = [int(num) for num in nums]
print(sorted(nums))


