N = input()
LS = input()
LS = list(sorted(map(int, LS.split())))

print(*LS)