#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

int main(){
    int n;
    cin >> n;
    vector<int> A(n);

    for(int i =0 ; i < n; ++i){
        cin >> A[i];
    }
    sort(A.begin(), A.end());
    for(auto el : A){
        cout << el << ' ';
    }

    return 0;
}