import sys

size = sys.stdin.readline()
inp = sys.stdin.readline()
a = [ int(x) for x in inp.split() ]
b =  a.sort()
print(' '.join([str(x) for x in a ]))
