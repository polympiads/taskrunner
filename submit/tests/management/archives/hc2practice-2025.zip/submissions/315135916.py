x  =input()
L=[]
L=list(map(int,input().split()))
L.sort()
print(L)