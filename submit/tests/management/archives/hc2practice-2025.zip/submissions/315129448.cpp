#include <bits/stdc++.h>

using namespace std;

#define int int64_t

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    
    
    int n;
    cin >> n;
    vector<int> result(n);
    for(int i =0; i<n;i++){
        cin >> result[i];
    }
    sort(result.begin(), result.end());
    for(int i =0; i<n;i++){
        cout << result[i] << " ";
    }
    cout << "\n";
}
