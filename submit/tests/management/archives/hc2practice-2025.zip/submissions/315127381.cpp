#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int a, b;
    std::cin >> a;
    std::vector<int> list;
    for (int i = 0; i < a; ++i) {
        std::cin >> b;
        list.push_back(b);
    }
    sort(list.first(), list.end());
    for (int i == 0; i < a; ++i) {
        std::cout << list[i] << " ";
    }
    return 0;
}