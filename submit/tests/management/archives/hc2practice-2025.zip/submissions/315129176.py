import java.io.BufferedInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class b {
    public static void main(String args[]) {
        auto sc = new Scanner(new BufferedInputStream(System.in));
        int n = sc.nextInt();
        List<Integer> a = new ArrayList<>();
        for (int i=0;i<n;++i){
            int b = sc.nextInt();
            a.add(b);
        }
        a.sort();
        for (auto b: a) {
            System.out.print(b, ' ');
        }
    }
}
