import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Scanner;
import java.util.StringTokenizer;

public class template {
    public static void main(String[] args) throws IOException {
        BufferedReader newscanner = new BufferedReader(new InputStreamReader(System.in));
        BufferedOutputStream stream = new BufferedOutputStream(System.out);
        StringTokenizer firstLine = new StringTokenizer(newscanner.readLine());
        int n = Integer.parseInt(firstLine.nextToken());
        firstLine = new StringTokenizer(newscanner.readLine());
        int[] array = new int[n];
        for(int i =0 ; i< n; i++){
            array[i] = Integer.parseInt(firstLine.nextToken());
        }
        Arrays.sort(array);
        for(int i = 0; i < n; i++){
            Integer temp = array[i];
            stream.write(temp.toString().getBytes());
            stream.write(" ".getBytes());
        }
    }
}
