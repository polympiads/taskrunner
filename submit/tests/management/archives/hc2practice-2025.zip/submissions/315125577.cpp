//#include <bits/stdc++.h>
#include <iostream>

#define int long long

using namespace std;

signed main() {
    
    int a,b;
    cin >> a >> b;
    cout << a + b;
}