#include <bits/stdc++.h>

#define int long long 

using namespace std;

signed main() {
    cin.tie(0);
    ios_base::sync_with_stdio(0);
    int a, b;

    cin >> a >> b;

    cout << a + b << '\n';
}
