#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll MXN = 1e6 + 10;

ll n, A[MXN];
void solve(){
    cin >> n;
    for(int i = 1; i <= n; i ++) cin >> A[i];
    sort(A + 1, A + n + 1);
    for(int i = 1; i <= n; i ++) cout << A[i] << ' ';
    cout << '\n';
}
int32_t main(){
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    solve();
    return 0;
}