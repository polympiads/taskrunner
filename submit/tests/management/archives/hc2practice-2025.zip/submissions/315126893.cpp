#include <bits/stdc++.h>
#define 



using namespace std;

int main(){
    int n,m; cin >> n >> m;
    cout << n+m << endl;
    return 0;
}