import sys
input = sys.stdin.readline

# a, b = list(map int, input().strip().split())

a, b = list(input().strip().split())

print(a+b)