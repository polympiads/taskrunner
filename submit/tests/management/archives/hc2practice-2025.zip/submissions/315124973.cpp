#include <bits/stdc++.h>

using namespace std;
using ll = long long;

vector<ll> a;
ll n;

int main() {
    cin >> n;
    a.resize(n);
    for (auto &x : a) cin >> x;
    sort(a.begin(), a.end());
    for (auto x : a) {
        cout << x << " ";
    }
}