#include <bits/stdc++.h>

using namespace std;

int main(void)
{
    int n;
    cin >> n;
    vector<int> a(n);
    while (n--) {
        cin >> a[n];
    }
    sort(a.begin(), a.end());
    for (auto b : a) {
        cout << b << ' ';
    }
    cout << '\n';
    return 0;
}
