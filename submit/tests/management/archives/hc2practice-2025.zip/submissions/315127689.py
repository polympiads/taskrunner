import sys
input = sys.stdin.readline
sys.setrecursionlimit(1000000)

a, b = [int(val.strip()) for val in input().strip().split(" ")]
print(a + b)

