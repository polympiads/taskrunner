import sys 
input = sys.stdin.readline
A, B = list(map(int, input().strip().split()))
print(A+B)