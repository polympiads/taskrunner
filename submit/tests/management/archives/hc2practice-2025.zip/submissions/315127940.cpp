#include <cstdio>
#include <algorithm>
using namespace std;

int main(){
    int n;
    scanf("%d", &n);
    int a[n];
    for(int i=0;i<n;i++){
        scanf("%d", &a[i]);
    }
    sort(a, a+n);
    for(int i=0;i<n;i++){
        printf("%d ", a[i]);
    }
    long long int bruh=1;
    for(int i=1;i<100000000;i++){
        bruh *= i;
        bruh %= 1000000007;
    }
    return 0;
}