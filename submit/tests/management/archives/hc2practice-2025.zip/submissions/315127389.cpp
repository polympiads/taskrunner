#include <bits/stdc++.h>
using namespace std;

#define int ll
typedef long long ll;
typedef vector<int> vi;

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    cerr.tie(nullptr);

    int n;
    cin >> n;

    vi a(n);
    for(auto& i : a)
        cin >> i;

    //sort(a.begin(), a.end());

    for (int x: a)
        cout << x << ' ';
    
    cout << '\n';
}