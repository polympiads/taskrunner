import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {
    public static void main(String[] args) {
        int n;
        FastScanner sc = new FastScanner();
        n = sc.nextInt();
        ArrayList<Integer> a = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            int x = sc.nextInt();
            a.add(x);
        }
        for (int i = 0; i < 1e9;i++) {
            int x;
            x= 1;
        }
        Collections.sort(a);
        StringBuilder sb = new StringBuilder();
        for (int x : a) {
            sb.append(x + " ");
        }
        System.out.println(sb);
    }
    static class FastScanner {
        StringTokenizer s;
        BufferedReader b;
        public FastScanner() {
            b = new BufferedReader(new InputStreamReader(System.in));
        }
        public String next() {
            while(s == null || !s.hasMoreTokens()) {
                try {
                    s = new StringTokenizer(b.readLine());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return s.nextToken();
        }
        public int nextInt() {
            return Integer.parseInt(next());
        }
    }
}