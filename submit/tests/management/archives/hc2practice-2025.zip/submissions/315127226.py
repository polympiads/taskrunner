import os

with open("input.fd0138e687.txt", "r") as f:
    data = f.read()

examples = data.split("\n")
for example in examples:
    inps = example.split(" ")
    print(int(inps[0]) + int(inps[1]))