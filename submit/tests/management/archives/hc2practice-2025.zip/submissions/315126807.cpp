#include <cstdio>
#include <iostream>
#include <cstdlib>
#include <vector>
#include <algorithm>

using namespace std;

typedef vector<int> vi;

#define SORT(a) sort((a).begin(),(a).end())
#define REP(i,n)  for(int i=0;i<(n);i++)

int main(){
    int n;
    cin>>n;
    vi v(n);
    REP(i,n){
        scanf("%d",&v[i]);
    }
    SORT(v);
    REP(i,n)cout<<v[i]<<' ';puts("");
    return 0;
}