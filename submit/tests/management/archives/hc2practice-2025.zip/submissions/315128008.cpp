#include <iostream>
#include <array>
#include <algorithm>
#include <numeric>
#include <fstream>
#include <cmath>

using namespace std;

int main(){
    int N;
    cin >> N;
    vector<int> numbers(N, 1);
    for(int i = 0; i < N ; i++){
        cin >> numbers[i];
    }
    sort(numbers.begin(), numbers.end());
    for (auto num: numbers){
        cout << num << " ";
    }
    cout << endl;
    return 1;
}