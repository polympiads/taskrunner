#include<bits/stdc++.h>
#define int int64_t
#define all(x) (x).begin(), (x).end()

using namespace std;

signed main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	
	int n; cin >> n;
	vector<int>A(n);
	for(int i = 0; i< n; i++)cin >> A[i];
	sort(all(A));
	for(auto e : A)cout << e << ' ';
}
