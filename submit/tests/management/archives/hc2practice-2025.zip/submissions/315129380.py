A, B = input()
print(A+B)