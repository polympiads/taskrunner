N = input()
xs = list(sorted([int(x) for x in input().split()]))
print(" ".join(xs))
