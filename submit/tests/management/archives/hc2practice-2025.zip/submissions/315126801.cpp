#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int a, b;
    std::cin >> a;
    int vector<int> list;
    for (int i = 0; i < a; ++i) {
        std::cin >> b;
        list.push(b);
    }
    std::sort(list);
    for (int i == 0; i < a; ++i) {
        std::cout << list[i] << " ";
    }
    return 0;
}