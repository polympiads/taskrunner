// #include <stdio.h>
#include <iostream.h>

int main() {
    int a, b;
    std::cin >> a >> b;
    std::cout << a + b;
    return 0;
}