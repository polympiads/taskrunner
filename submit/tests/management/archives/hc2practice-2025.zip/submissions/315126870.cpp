#include<iostream>
#include<vector>
#include<algorithm>

int main() {
    int n;
    std::cin >> n;
    std::vector<int> a;
    int t;
    for (int i =0; i<n;i++) {
        std::cin >> t;
        a.push_back(t);
       }

    std::sort(a.begin(), a.end());
    for (auto i : a)
    std::cout << i << ' ';
    std::cout << '\n';

    return 0;
}
