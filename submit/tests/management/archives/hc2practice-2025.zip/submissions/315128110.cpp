#include <bits/stdc++.h>

using namespace std;

int main() {
    int n; cin >> n;
    vector<int> a(3);
    for (int i = 0; i < n; i++) cin >> a[i];
    for (int i = 0; i < 1000000000;i++) {
        sort(a.begin(), a.end());
        for (auto e: a) cout << e << " ";
    }
    
}