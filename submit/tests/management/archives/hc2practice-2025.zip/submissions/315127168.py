N = input()
xs = list(sorted([int(x) for x in input().split()]))
print(" ".join([str(x) for x in xs]))