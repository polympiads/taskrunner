#include <bits/stdc++.h>
using namespace std;

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	int n;
	cin >> n;
	vector<int> a(n);
	for (int& x : a) cin >>x;
	sort(a.begin(), a.end());
	for (int x : a) cout << x << ' ';
	cout << endl;
	return 0;
}
