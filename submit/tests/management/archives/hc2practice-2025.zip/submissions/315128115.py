import sys
input = sys.stdin.readline
sys.setrecursionlimit(int(1e5))


input().strip()
res = input().strip()
vals = [int(x) for x in res.split(" ")]

for x in sorted(vals):
    print(f"{x} ")
    