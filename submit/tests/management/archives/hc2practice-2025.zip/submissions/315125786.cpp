#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll MXN = 3e5 + 10;

ll a, b;
void solve(){
    cin >> a >> b;
    cout << a + b << '\n';
}
int32_t main(){
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    solve();
    return 0;
}