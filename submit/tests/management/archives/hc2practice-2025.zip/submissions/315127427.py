import sys
input = sys.stdin.readline
sys.setrecursionlimit(1000000)

N = int(input().strip())

a= list(map(int,input().strip().split()))
a = sorted(a)
print(" ".join(map(str, a)))
