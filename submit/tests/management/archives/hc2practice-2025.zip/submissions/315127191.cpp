#include <vector>
#include <stdio.h>
#include <algorithm>

int main() {
	int n;
	scanf("%d", &n);
	std::vector<int> v(n);
	for (int i=0; i<n; i++) {
		scanf("%d", &v[i]);
	}
	std::sort(v.begin(), v.end());
	for (int i=0; i<n; i++) {
		printf("%d ", v[i]);
	}
	printf("\n");
}