
num = int(input().strip())
l = list(map( lambda x : int(x), input().strip().split(" ")))
l.sort()

print(" ".join(list(map(str,l))))