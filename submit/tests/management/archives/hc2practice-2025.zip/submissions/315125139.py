input()
lst = map(int, list(input().split()))
print(*sorted(lst))