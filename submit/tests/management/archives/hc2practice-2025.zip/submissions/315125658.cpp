import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {
    public static void main(String[] args) {
        int a, b;
        FastScanner sc = new FastScanner();
        a = sc.nextInt();
        b = sc.nextInt();
        System.out.println(a + b);
    }
    static class FastScanner {
        StringTokenizer s;
        BufferedReader b;
        public FastScanner() {
            b = new BufferedReader(new InputStreamReader(System.in));
        }
        public String next() {
            while(s == null || !s.hasMoreTokens()) {
                try {
                    s = new StringTokenizer(b.readLine());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return s.nextToken();
        }
        public int nextInt() {
            return Integer.parseInt(next());
        }
    }
}