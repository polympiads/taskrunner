#include<iostream>
#include<bits/stdc++.h>

using namespace std;

int main(){
    vector<int> vect;
    int n;
    cin >> n;
    for (size_t i(0); i < n; i++){
        int a;
        cin >> a;
        vect.push_back(a);
    }
    sort(vect.begin(),vect.end())
    for (auto n : vect){
        cout << n << " ";
    }
    return 0;
}