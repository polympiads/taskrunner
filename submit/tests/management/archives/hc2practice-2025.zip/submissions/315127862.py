import sys 
input1 = sys.stdin.readline
input2 = sys.stdin.readline
A = int(input1().strip())
B = list(map(int, input1().strip().split()))

C = ""

for i in range(A):
    M = min(B)
    ind = B.index(M)
    B.pop(ind)
    C += str(M) + " "



print(C.strip())

