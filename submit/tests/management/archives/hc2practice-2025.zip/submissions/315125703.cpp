#include <cstdio>
#include <algorithm>
#include <vector>
using namespace std;

int main()
{
    int n;
    vector<int> a;
    
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        int x;
        scanf("%d", &x);
        a.push_back(x);
    }
    
    sort(a.begin(), a.end());
    
    for (int i = 0; i < n; i++) printf("%d%s", a[i], i == n-1 ? " " : "\n");
    
    return 0;
}