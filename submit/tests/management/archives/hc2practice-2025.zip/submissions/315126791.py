import sys

input = sys.stdin.readline

add1 = int(input().strip())
add2 = int(input().strip())

if __name__ == '__main__':
    print(add1+add2)
