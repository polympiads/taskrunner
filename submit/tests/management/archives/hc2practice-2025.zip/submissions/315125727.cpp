#include <bits/stdc++.h>
using namespace std;
#define int int64_t

signed main(){
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
		
	int n; cin>>n;
	vector<int>v(n);
	for(auto&u: v) cin>>u;
	
	sort(v.begin(), v.end());
	
	
	for(auto u: v) cout<<u<<" ";
	cout<<'\n';
	
}
