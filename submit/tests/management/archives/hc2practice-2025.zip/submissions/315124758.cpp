#include <bits/stdc++.h>

using namespace std;
using ll = long long;

ll a, b;

int main() {
    cin >> a >> b;
    cout << a + b;
    return 0;
}