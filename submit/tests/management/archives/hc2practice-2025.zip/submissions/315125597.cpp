#include <iostream>
using namespace std;

#define BALAST ios::sync_with_stdio(false);cin.tie(NULL);

int main() {
    BALAST;

    int a, b;
    cin >> a >> b;
    cout << a + b;
    return 0;
}