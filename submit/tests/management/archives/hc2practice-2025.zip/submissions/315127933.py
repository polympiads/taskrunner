import sys
input = sys.stdin.readline
sys.setrecursionlimit(int(1e5))


res = input().strip()
vals = res.split(" ")

print(int(vals[0]) + int(vals[1]))