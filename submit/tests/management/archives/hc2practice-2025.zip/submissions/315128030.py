import sys
input = sys.stdin.readline
sys.setrecursionlimit(1000000)

a, b = list(map(int, input().strip().split()))
print(a + b)

