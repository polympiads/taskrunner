s = input()
l = list(map(int, s.split()))
l.sort()
print(*l, sep=' ')