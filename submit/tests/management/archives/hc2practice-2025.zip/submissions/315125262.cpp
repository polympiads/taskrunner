#include <bits/stdc++.h>
using namespace std;

int main() {
  int n;
  vector<int> x;
  scanf("%d", &n);
  x.resize(n);
  for(int i=0; i<n; i++) {
    scanf("%d", &x[i]);
  }
  sort(x.begin(), x.end());
  for(int i=0; i<n; i++) {
    printf("%s%d", i==0 ? "" : " ", x[i]);
  }
  printf("\n");

  return 0;
}
