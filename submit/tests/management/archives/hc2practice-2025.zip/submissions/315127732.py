import sys

input = sys.stdin.readline

l = list(map(int, input().strip().split()))

if __name__ == '__main__':
    print(l[0]+l[1])