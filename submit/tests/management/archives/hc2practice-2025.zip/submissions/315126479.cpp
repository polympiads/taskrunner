#include <bits/stdc++.h>
using namespace std;

#define ll long long
const ll MAXN = 1e5;
ll a[MAXN];
ll n,m,k;

int main() {
    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    for (int i = 0; i < n; i++)  {
        for (int j = 0; j < n-1; j++) {
            if (a[j] > a[j+1]) {
                ll tmp = a[j];
                a[j] = a[j+1];
                a[j+1] = tmp;
            }
        }
    }
    for (int i = 0 ; i < n; i++) {
        cout << a[i] << " ";
    }
    cout << endl;
}