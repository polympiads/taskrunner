x  =input()
L=[]
L=map(int,input().split())
L.sort()
print(L)