
n1 = int(input().strip())

l = list(map(int, input().strip().split()))

if __name__ == '__main__':
    l.sort()
    for i in l:
        print(i,end=' ')
        print('')