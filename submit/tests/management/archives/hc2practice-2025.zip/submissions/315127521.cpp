#include<bits/stdc++.h>
#define int int64_t

using namespace std;

signed main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	
	int a, b; cin >> a >> b;
	cout << a + b;
}
