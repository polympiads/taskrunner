#include <bits/stdc++.h>
using namespace std;

#define ll long long
const ll MAXN = 1e5;
ll a[MAXN];
ll n,m,k;

bool check() {
    for (int i = 0 ; i<n-1; i++) {
        if (a[i+1] < a[i]) return false;
    }
    return true;
}

int main() {
    cin >> n;

    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    
    while (true) {

        int pos1 = rand()%n;
        int pos2= rand()%n;
       
        int tmp = a[pos1];
        a[pos1] = a[pos2];
        a[pos2] = tmp;

        if (check()) {
            for (int i = 0; i < n; i++) {
                cout << a[i] << " ";
            }
            cout << endl;
            return 0;
        }
    }
}