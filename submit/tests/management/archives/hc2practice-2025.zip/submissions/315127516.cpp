#include <bits/stdc++.h>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int n; cin >> n;
    vector<int> a(n);
    for (auto& e: a) cin >> e;
    sort(a.begin(), a.end());
    for (auto e: a) cout << e << " ";
}