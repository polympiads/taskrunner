n = int(input())
arr = [int(v) for v in input().split()]
arr = sorted(arr)
print(' '.join(str(v) for v in arr))