#include <iostream>

using namespace std;


int main(){
    int N;
    cin >> N;
    array<int> numbers[N];
    cin >> numbers;
    sort(numbers);
    cout << numbers;
}