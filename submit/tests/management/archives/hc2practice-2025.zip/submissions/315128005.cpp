#include <bits/stdc++.h>

#define int long long 

using namespace std;

signed main() {
    cin.tie(0);
    ios_base::sync_with_stdio(0);
    int n;

    cin >> n;
    vector<int> l(n);

    for (int i = 0; i < n; i ++){
        cin >> l[i];

    }
    sort(l.begin(), l.end());

    for (int i = 0; i < n; i ++){
        cout << l[i] << " ";
    }

    cout << '\n';
}
