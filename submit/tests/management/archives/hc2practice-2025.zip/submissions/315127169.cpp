#include <bits/stdc++.h>

using namespace std;

#define int int64_t

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    
    
    int a, b;
    cin >> a >> b;

    cout << a + b << "\n";

    return 0;
}
