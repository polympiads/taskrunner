#include <bits/stdc++.h>

#define forn(i, n) for (int i = 0; i < int(n); i++)

#ifdef SU1
#define LOG
#endif

using namespace std;

auto now() { return std::chrono::high_resolution_clock::now(); }

int a, b;

bool read() {
	return scanf("%d%d", &a, &b) == 2;
}

void solve() {
	printf("%d\n", a + b);
}

int main() {
	while (read()) {
#ifdef LOG
		auto start = now();
#endif
		solve();
#ifdef LOG
		auto duration = (now() - start).count();
		cerr << fixed << setprecision(3) << "time: " << duration / 1e9 << "s" << endl;
#endif
	}
	return 0;
}
