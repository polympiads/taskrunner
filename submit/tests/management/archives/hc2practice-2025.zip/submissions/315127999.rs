use std::io;

fn main() {
    let stdin = io::stdin();
    let mut n = String::new();
    stdin.read_line(&mut n).expect("wrong fromat");
    let mut line = String::new();
    stdin.read_line(&mut line).expect("wrong format");
    let mut line: Vec<i32> = line.split_whitespace().map(|s| s.parse().expect("wrong format")).collect();
    line.sort();
    println!("{}",line.into_iter().map(|s| s.to_string()).collect::<Vec<String>>().join(" "));
}