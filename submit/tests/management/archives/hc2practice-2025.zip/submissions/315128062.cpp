#include <bits/stdc++.h>

using namespace std;
 
int main() {
	int n;
        cin >> n;

	vector<int> vec;

	for (int i = 0; i < n; i++) {
		int tmp;
		cin >> tmp;
		vec.push_back(tmp);
	}

	sort(vec.begin(), vec.end());

	for (int e : vec) cout << e << " ";
	cout << endl;
}
