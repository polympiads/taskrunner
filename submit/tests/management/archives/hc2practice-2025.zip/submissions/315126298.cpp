#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef vector<pair<int, int>> vii;
typedef vector<vector<int>> vvi;

ll gcd(ll a, ll b) {if (b==0)return a; return gcd(b,a%b);}
ll lcm(ll a, ll b){return (a*b) / gcd(a, b);}

bool isPowerOfTwo(ll x){if (x < 0) return false; return x && (!(x & (x - 1)));}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    // cout << gcd(81, 9) << "\n";
    int n;
    cin >> n;
    vector<int> a(n);
    for (int i = 0; i<n; i++) {
        cin >> a[i];
    }
    sort(a.begin(),a.end());
    for (int i : a) {
        cout << i << " ";
    }
    return 0;
}
