import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class template {
    public static void main(String[] args) throws IOException {
        BufferedReader scanner = new BufferedReader(new InputStreamReader(System.in));
        BufferedOutputStream stream = new BufferedOutputStream(System.out);

        StringTokenizer firstLine = new StringTokenizer(scanner.readLine());
        int a = Integer.parseInt(firstLine.nextToken());
        int b = Integer.parseInt(firstLine.nextToken());
        Integer res = a + b;
        stream.write(res.toString().getBytes());
        stream.write(("\n").getBytes());
    }
}