input()
a=list(map(int,input().split()))
a.sort()
for b in a:
    print(b,end=" ")