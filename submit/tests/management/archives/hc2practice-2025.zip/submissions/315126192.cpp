#include <iostream>
#include <bits/stdc++.h>
using namespace std;

#define BALAST ios::sync_with_stdio(false);cin.tie(NULL);

const int nmax = 100'000;
int a[nmax+1];

int main() {
    BALAST;

    int n, i;
    cin >> n;
    for(i = 1; i<=n; i++)
        cin >> a[i];

    sort(a+1, a+n+1);
    for (i = 1; i<=n; i++)
        cout << a[i] << ' ';
    return 0;
}