<!DOCTYPE html>
<html lang="en" dir="ltr" class="client-nojs">
<head>
<title>cppreference.com</title>
<meta charset="UTF-8">
<meta name="generator" content="MediaWiki 1.21.2">
<link rel="shortcut icon" href="../common/favicon.ico">
<link rel="stylesheet" href="../common/ext.css">
<meta name="ResourceLoaderDynamicStyles" content="">
<link rel="stylesheet" href="../common/site_modules.css">
<style>a:lang(ar),a:lang(ckb),a:lang(fa),a:lang(kk-arab),a:lang(mzn),a:lang(ps),a:lang(ur){text-decoration:none}#toc{display:none}.editsection{display:none}
/* cache key: mwiki1-mwiki_en_:resourceloader:filter:minify-css:7:472787eddcf4605d11de8c7ef047234f */</style>

<script src="../common/startup_scripts.js"></script>
<script>if(window.mw){
mw.config.set({"wgCanonicalNamespace":"","wgCanonicalSpecialPageName":false,"wgNamespaceNumber":0,"wgPageName":"Main_Page","wgTitle":"Main Page","wgCurRevisionId":110059,"wgArticleId":1,"wgIsArticle":true,"wgAction":"view","wgUserName":null,"wgUserGroups":["*"],"wgCategories":[],"wgBreakFrames":false,"wgPageContentLanguage":"en","wgSeparatorTransformTable":["",""],"wgDigitTransformTable":["",""],"wgDefaultDateFormat":"dmy","wgMonthNames":["","January","February","March","April","May","June","July","August","September","October","November","December"],"wgMonthNamesShort":["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"wgRelevantPageName":"Main_Page","wgRestrictionEdit":["autoconfirmed"],"wgRestrictionMove":["autoconfirmed"],"wgIsMainPage":true});
}</script><script>if(window.mw){
mw.loader.implement("user.options",function(){mw.user.options.set({"ccmeonemails":0,"cols":80,"date":"default","diffonly":0,"disablemail":0,"disablesuggest":0,"editfont":"default","editondblclick":0,"editsection":0,"editsectiononrightclick":0,"enotifminoredits":0,"enotifrevealaddr":0,"enotifusertalkpages":1,"enotifwatchlistpages":0,"extendwatchlist":0,"externaldiff":0,"externaleditor":0,"fancysig":0,"forceeditsummary":0,"gender":"unknown","hideminor":0,"hidepatrolled":0,"imagesize":2,"justify":0,"math":1,"minordefault":0,"newpageshidepatrolled":0,"nocache":0,"noconvertlink":0,"norollbackdiff":0,"numberheadings":0,"previewonfirst":0,"previewontop":1,"quickbar":5,"rcdays":7,"rclimit":50,"rememberpassword":0,"rows":25,"searchlimit":20,"showhiddencats":0,"showjumplinks":1,"shownumberswatching":1,"showtoc":0,"showtoolbar":1,"skin":"cppreference2","stubthreshold":0,"thumbsize":2,"underline":2,"uselivepreview":0,"usenewrc":0,"watchcreations":0,"watchdefault":0,"watchdeletion":0,
"watchlistdays":3,"watchlisthideanons":0,"watchlisthidebots":0,"watchlisthideliu":0,"watchlisthideminor":0,"watchlisthideown":0,"watchlisthidepatrolled":0,"watchmoves":0,"wllimit":250,"variant":"en","language":"en","searchNs0":true,"searchNs1":false,"searchNs2":false,"searchNs3":false,"searchNs4":false,"searchNs5":false,"searchNs6":false,"searchNs7":false,"searchNs8":false,"searchNs9":false,"searchNs10":false,"searchNs11":false,"searchNs12":false,"searchNs13":false,"searchNs14":false,"searchNs15":false,"gadget-ColiruCompiler":1,"gadget-MathJax":1});;},{},{});mw.loader.implement("user.tokens",function(){mw.user.tokens.set({"editToken":"+\\","patrolToken":false,"watchToken":false});;},{},{});
/* cache key: mwiki1-mwiki_en_:resourceloader:filter:minify-js:7:9f05c6caceb9bb1a482b6cebd4c5a330 */
}</script>
<script>if(window.mw){
mw.loader.load(["mediawiki.page.startup","mediawiki.legacy.wikibits","mediawiki.legacy.ajax"]);
}</script>
<!--[if lt IE 7]><style type="text/css">body{behavior:url("/mwiki/skins/cppreference2/csshover.min.htc")}</style><![endif]--></head>
<body class="mediawiki ltr sitedir-ltr ns-0 ns-subject page-Main_Page skin-cppreference2 action-view">
        <!-- header -->
        <!-- /header -->
        <!-- content -->
<div id="cpp-content-base">
            <div id="content">
                <a id="top"></a>
                <div id="mw-js-message" style="display:none;"></div>
                                <!-- firstHeading -->
<h1 id="firstHeading" class="firstHeading">C and C++ reference</h1>
                <!-- /firstHeading -->
                <!-- bodyContent -->
                <div id="bodyContent">
                                        <!-- tagline -->
                    <div id="siteSub">From cppreference.com</div>
                    <!-- /tagline -->
                                        <!-- subtitle -->
                    <div id="contentSub"></div>
                    <!-- /subtitle -->
                                                            <!-- bodycontent -->
                    <div id="mw-content-text" lang="en" dir="ltr" class="mw-content-ltr"><table class="mainpagetable" cellspacing="0" style="width:100%; white-space:nowrap;">

<tr class="row rowtop">
<td colspan="3">
<p><a href="cpp.html" title="cpp"><span style="font-size: 2em;">C++ reference</span><br>
<span style="font-size: 0.8em;">C++98, C++03, C++11, C++14, C++17, C++20</span>
</a>
</p>
</td></tr>
<tr class="row">
<td>
<div class="mainpagediv">
<p><a href="cpp/compiler_support.html" title="cpp/compiler support"> Compiler support</a><br>
<a href="cpp/freestanding.html" title="cpp/freestanding"> Freestanding implementations</a>
</p>
</div>
<p><b><a href="cpp/language.html" title="cpp/language"> Language</a></b>
</p>
<div class="mainpagediv">
<p><a href="cpp/language/basic_concepts.html" title="cpp/language/basic concepts"> Basic concepts</a><br>
<a href="cpp/keywords.html" title="cpp/keyword"> C++ Keywords</a><br>
<a href="cpp/preprocessor.html" title="cpp/preprocessor"> Preprocessor</a><br>
<a href="cpp/language/expressions.html" title="cpp/language/expressions"> Expressions</a><br>
<a href="cpp/language/declarations.html" title="cpp/language/declarations"> Declaration</a><br>
<a href="cpp/language/initialization.html" title="cpp/language/initialization"> Initialization</a><br>
<a href="cpp/language/functions.html" title="cpp/language/functions"> Functions</a><br>
<a href="cpp/language/statements.html" title="cpp/language/statements"> Statements</a><br>
<a href="cpp/language/classes.html" title="cpp/language/classes"> Classes</a><br>
<a href="cpp/language/templates.html" title="cpp/language/templates"> Templates</a><br>
<a href="cpp/language/exceptions.html" title="cpp/language/exceptions"> Exceptions</a><br>
</p>
</div>
<p><b><a href="cpp/header.html" title="cpp/header"> Headers</a></b>
</p><p><b><a href="cpp/named_req.html" title="cpp/named req"> Named requirements</a></b>
</p><p><b><a href="cpp/feature_test.html" title="cpp/feature test">Feature test macros</a></b> <span class="t-mark-rev t-since-cxx20">(C++20)</span>
</p><p><b><a href="cpp/utility.html#Language_support" title="cpp/utility"> Language support library</a></b>
</p>
<div class="mainpagediv">
<p><a href="cpp/types.html" title="cpp/types"> Type support</a>  −  <a href="cpp/types.html#Type_traits_.28since_C.2B.2B11.29" title="cpp/types">traits</a> <span class="t-mark-rev t-since-cxx11">(C++11)</span><br>
<a href="cpp/utility/program.html" title="cpp/utility/program"> Program utilities</a><br>
<a href="cpp/utility.html#Relational_operators_and_comparison" title="cpp/utility"> Relational comparators</a> <span class="t-mark-rev t-since-cxx20">(C++20)</span><br>
<a href="cpp/types/numeric_limits.html" title="cpp/types/numeric limits"><tt>numeric_limits</tt></a>  −  <a href="cpp/types/type_info.html" title="cpp/types/type info"><tt>type_info</tt></a><br>
<a href="cpp/utility/initializer_list.html" title="cpp/utility/initializer list"><tt>initializer_list</tt></a> <span class="t-mark-rev t-since-cxx11">(C++11)</span><br>
</p>
</div>
</td>
<td>
<p><b><a href="cpp/concepts.html" title="cpp/concepts"> Concepts library</a></b> <span class="t-mark-rev t-since-cxx20">(C++20)</span>
</p><p><b><a href="cpp/error.html" title="cpp/error"> Diagnostics library</a></b>
</p><p><b><a href="cpp/utility.html#General-purpose_utilities" title="cpp/utility"> General utilities library</a></b>
</p>
<div class="mainpagediv">
<p><a href="cpp/memory.html" title="cpp/memory"> Smart pointers and allocators</a><br>
<a href="cpp/chrono.html" title="cpp/chrono"> Date and time</a><br>
<a href="cpp/utility/functional.html" title="cpp/utility/functional"> Function objects</a>  −  <a href="cpp/utility/hash.html" title="cpp/utility/hash"><tt>hash</tt></a> <span class="t-mark-rev t-since-cxx11">(C++11)</span><br>
<a href="cpp/utility.html#Elementary_string_conversions" title="cpp/utility"> String conversions</a> <span class="t-mark-rev t-since-cxx17">(C++17)</span><br>
<a href="cpp/utility.html#Swap.2C_forward_and_move" title="cpp/utility"> Utility functions</a><br>
<a href="cpp/utility/pair.html" title="cpp/utility/pair"><tt>pair</tt></a>  −  
<a href="cpp/utility/tuple.html" title="cpp/utility/tuple"><tt>tuple</tt></a> <span class="t-mark-rev t-since-cxx11">(C++11)</span><br>
<a href="cpp/utility/optional.html" title="cpp/utility/optional"><tt>optional</tt></a> <span class="t-mark-rev t-since-cxx17">(C++17)</span>  −  <a href="cpp/utility/any.html" title="cpp/utility/any"><tt>any</tt></a> <span class="t-mark-rev t-since-cxx17">(C++17)</span><br>
<a href="cpp/utility/variant.html" title="cpp/utility/variant"><tt>variant</tt></a> <span class="t-mark-rev t-since-cxx17">(C++17)</span>
</p>
</div>
<p><b><a href="cpp/string.html" title="cpp/string"> Strings library</a></b>
</p>
<div class="mainpagediv">
<p><a href="cpp/string/basic_string.html" title="cpp/string/basic string"><tt>basic_string</tt></a><br>
<a href="cpp/string/basic_string_view.html" title="cpp/string/basic string view"><tt>basic_string_view</tt></a> <span class="t-mark-rev t-since-cxx17">(C++17)</span><br>
Null-terminated strings:<br>
  <a href="cpp/string/byte.html" title="cpp/string/byte">byte</a>  −  <a href="cpp/string/multibyte.html" title="cpp/string/multibyte">multibyte</a>  −  <a href="cpp/string/wide.html" title="cpp/string/wide">wide</a>
</p>
</div>
<p><b><a href="cpp/container.html" title="cpp/container"> Containers library</a></b>
</p>
<div class="mainpagediv">
<p><a href="cpp/container/array.html" title="cpp/container/array"><tt>array</tt></a> <span class="t-mark-rev t-since-cxx11">(C++11)</span>  −  <a href="cpp/container/vector.html" title="cpp/container/vector"><tt>vector</tt></a><br>
<a href="cpp/container/map.html" title="cpp/container/map"><tt>map</tt></a>  −  <a href="cpp/container/unordered_map.html" title="cpp/container/unordered map"><tt>unordered_map</tt></a> <span class="t-mark-rev t-since-cxx11">(C++11)</span><br>
<a href="cpp/container/priority_queue.html" title="cpp/container/priority queue"><tt>priority_queue</tt></a>  −  <a href="cpp/container/span.html" title="cpp/container/span"><tt>span</tt></a> <span class="t-mark-rev t-since-cxx20">(C++20)</span><br>
Other containers:<br>
  <a href="cpp/container.html#Sequence_containers" title="cpp/container">sequence</a>  −  
<a href="cpp/container.html#Associative_containers" title="cpp/container">associative</a><br>
  <a href="cpp/container.html#Unordered_associative_containers" title="cpp/container">unordered associative</a>  −  <a href="cpp/container.html#Container_adaptors" title="cpp/container">adaptors</a>
</p>
</div>
</td>
<td>
<p><b><a href="cpp/iterator.html" title="cpp/iterator"> Iterators library</a></b>
</p><p><b><a href="cpp/ranges.html" title="cpp/ranges"> Ranges library</a></b> <span class="t-mark-rev t-since-cxx20">(C++20)</span>
</p><p><b><a href="cpp/algorithm.html" title="cpp/algorithm"> Algorithms library</a></b>
</p><p><b><a href="cpp/numeric.html" title="cpp/numeric"> Numerics library</a></b>
</p>
<div class="mainpagediv">
<p><a href="cpp/numeric/math.html" title="cpp/numeric/math"> Common math functions</a><br>
<a href="cpp/numeric/special_math.html" title="cpp/numeric/special math"> Special math functions</a> <span class="t-mark-rev t-since-cxx17">(C++17)</span><br>
<a href="cpp/numeric.html#Numeric_algorithms" title="cpp/numeric"> Numeric algorithms</a><br>
<a href="cpp/numeric/random.html" title="cpp/numeric/random"> Pseudo-random number generation</a><br>
<a href="cpp/numeric/fenv.html" title="cpp/numeric/fenv"> Floating-point environment</a> <span class="t-mark-rev t-since-cxx11">(C++11)</span><br>
<a href="cpp/numeric/complex.html" title="cpp/numeric/complex"><tt>complex</tt></a>  −  <a href="cpp/numeric/valarray.html" title="cpp/numeric/valarray"><tt>valarray</tt></a>
</p>
</div>
<p><b><a href="cpp/io.html" title="cpp/io"> Input/output library</a></b>
</p>
<div class="mainpagediv">
<p><a href="cpp/io.html#Stream-based_I.2FO" title="cpp/io"> Stream-based I/O</a><br>
<a href="cpp/io.html#Synchronized_output" title="cpp/io"> Synchronized output</a> <span class="t-mark-rev t-since-cxx20">(C++20)</span><br>
<a href="cpp/io/manip.html" title="cpp/io/manip"> I/O manipulators</a><br>
</p>
</div>
<p><b><a href="cpp/locale.html" title="cpp/locale"> Localizations library</a></b>
</p><p><b><a href="cpp/regex.html" title="cpp/regex"> Regular expressions library</a></b> <span class="t-mark-rev t-since-cxx11">(C++11)</span>
</p>
<div class="mainpagediv">
<p><a href="cpp/regex/basic_regex.html" title="cpp/regex/basic regex"><tt>basic_regex</tt></a>  −  <a href="cpp/regex.html#Algorithms" title="cpp/regex">algorithms</a>
</p>
</div>
<p><b><a href="cpp/atomic.html" title="cpp/atomic"> Atomic operations library</a></b> <span class="t-mark-rev t-since-cxx11">(C++11)</span>
</p>
<div class="mainpagediv">
<p><a href="cpp/atomic/atomic.html" title="cpp/atomic/atomic"><tt>atomic</tt></a>  −  <a href="cpp/atomic/atomic_flag.html" title="cpp/atomic/atomic flag"><tt>atomic_flag</tt></a><br>
<a href="cpp/atomic/atomic_ref.html" title="cpp/atomic/atomic ref"><tt>atomic_ref</tt></a> <span class="t-mark-rev t-since-cxx20">(C++20)</span>
</p>
</div>
<p><b><a href="cpp/thread.html" title="cpp/thread"> Thread support library</a></b> <span class="t-mark-rev t-since-cxx11">(C++11)</span>
</p><p><b><a href="cpp/filesystem.html" title="cpp/filesystem"> Filesystem library</a></b> <span class="t-mark-rev t-since-cxx17">(C++17)</span>
</p>
</td></tr>
<tr class="row">
<td colspan="3"><b><a href="cpp/experimental.html" title="cpp/experimental"> Technical specifications</a></b><br>
<p>  <b><a href="cpp/experimental/memory.html" title="cpp/experimental/lib extensions">Standard library extensions</a></b>  <span class="t-mark-rev t-since-libfund-ts t-mark-ts">(library fundamentals TS)</span><br>
  <b><a href="cpp/experimental/lib_extensions_2.html" title="cpp/experimental/lib extensions 2">Standard library extensions v2</a></b>  <span class="t-mark-rev t-since-libfund-ts-2 t-mark-ts">(library fundamentals TS v2)</span>
</p>
<div class="mainpagediv">
<p><a href="cpp/experimental/propagate_const.html" title="cpp/experimental/propagate const"><tt>propagate_const</tt></a> —
<a href="cpp/experimental/observer_ptr.html" title="cpp/experimental/observer ptr"><tt>observer_ptr</tt></a> — <a href="cpp/experimental/source_location.html" title="cpp/experimental/source location"><tt>source_location</tt></a> <br> <a href="cpp/experimental/ostream_joiner.html" title="cpp/experimental/ostream joiner"><tt>ostream_joiner</tt></a> —
<a href="cpp/experimental/is_detected.html" title="cpp/experimental/is detected">detection idiom</a> — <a href="cpp/experimental/lib_extensions_2.html#Uniform_container_erasure" title="cpp/experimental/lib extensions 2">uniform container erasure</a>
</p>
</div>
<p>  <b><a href="cpp/experimental/concurrency.html" title="cpp/experimental/concurrency">Concurrency library extensions</a></b>  <span class="t-mark-rev t-since-concurrency-ts t-mark-ts">(concurrency TS)</span><br>
  <b><a href="cpp/experimental/constraints.html" title="cpp/experimental/constraints">Concepts</a></b>  <span class="t-mark-rev t-since-concepts-ts t-mark-ts">(concepts TS)</span><br>
  <b><a href="cpp/experimental/ranges.html" title="cpp/experimental/ranges">Ranges</a></b>  <span class="t-mark-rev t-since-ranges-ts t-mark-ts">(ranges TS)</span><br>
  <b><a href="cpp/language/transactional_memory.html" title="cpp/language/transactional memory">Transactional Memory</a></b>  <span class="t-mark-rev t-since-tm-ts t-mark-ts">(TM TS)</span><br>
</p>
</td></tr>
<tr class="row rowbottom">
<td colspan="3"> <a href="cpp/links.html" title="cpp/links">External Links</a>  −  <a href="cpp/links/libs.html" title="cpp/links/libs">Non-ANSI/ISO Libraries</a>  −  <a href="cpp/index.html" title="cpp/index">Index</a>  −  <a href="cpp/symbol_index.html" title="cpp/symbol index">std Symbol Index</a>
</td></tr>
<tr>
<td> <span style="margin:12px;"></span>
</td></tr>
<tr class="row rowtop">
<td colspan="3">
<p><a href="c.html" title="c"><span style="font-size: 2em;">C reference</span><br>
<span style="font-size: 0.8em;">C89, C95, C99, C11, C17</span>
</a>
</p>
</td></tr>
<tr class="row">
<td>
<p><b><a href="c/language.html" title="c/language"> Language</a></b>
</p>
<div class="mainpagediv">
<p><a href="c/language/basic_concepts.html" title="c/language/basic concepts"> Basic concepts</a><br>
<a href="c/keyword.html" title="c/keyword"> C Keywords</a><br>
<a href="c/preprocessor.html" title="c/preprocessor"> Preprocessor</a><br>
<a href="c/language/expressions.html" title="c/language/expressions"> Expressions</a><br>
<a href="c/language/declarations.html" title="c/language/declarations"> Declaration</a><br>
<a href="c/language/initialization.html" title="c/language/initialization"> Initialization</a><br>
<a href="c/language/functions.html" title="c/language/functions"> Functions</a><br>
<a href="c/language/statements.html" title="c/language/statements"> Statements</a><br>
</p>
</div>
<p><b><a href="c/header.html" title="c/header"> Headers</a></b>
</p>
</td>
<td>
<p><b><a href="c/types.html" title="c/types"> Type support</a></b>
</p><p><b><a href="c/program.html" title="c/program"> Program utilities</a></b>
</p><p><b><a href="c/variadic.html" title="c/variadic"> Variadic functions</a></b>
</p><p><b><a href="c/error.html" title="c/error"> Error handling</a></b>
</p><p><b><a href="c/memory.html" title="c/memory"> Dynamic memory management</a></b>
</p><p><b><a href="c/chrono.html" title="c/chrono"> Date and time utilities</a></b>
</p><p><b><a href="c/string.html" title="c/string"> Strings library</a></b>
</p>
<div class="mainpagediv">
<p>Null-terminated strings:<br>
  <a href="c/string/byte.html" title="c/string/byte"> byte</a>  −  <a href="c/string/multibyte.html" title="c/string/multibyte"> multibyte</a>  −  <a href="c/string/wide.html" title="c/string/wide"> wide</a>
</p>
</div>
<p><b><a href="c/algorithm.html" title="c/algorithm"> Algorithms</a></b>
</p>
</td>
<td>
<p><b><a href="c/numeric.html" title="c/numeric"> Numerics</a></b>
</p>
<div class="mainpagediv">
<p><a href="c/numeric/math.html" title="c/numeric/math"> Common mathematical functions</a><br>
<a href="c/numeric/fenv.html" title="c/numeric/fenv"> Floating-point environment</a> <span class="t-mark-rev t-since-c99">(C99)</span><br>
<a href="c/numeric/random.html" title="c/numeric/random"> Pseudo-random number generation</a><br>
<a href="c/numeric/complex.html" title="c/numeric/complex"> Complex number arithmetic</a> <span class="t-mark-rev t-since-c99">(C99)</span><br>
<a href="c/numeric/tgmath.html" title="c/numeric/tgmath"> Type-generic math</a> <span class="t-mark-rev t-since-c99">(C99)</span>
</p>
</div>
<p><b><a href="c/io.html" title="c/io"> Input/output support</a></b>
</p><p><b><a href="c/locale.html" title="c/locale"> Localization support</a></b>
</p><p><b><a href="c/atomic.html" title="c/atomic"> Atomic operations library</a></b> <span class="t-mark-rev t-since-c11">(C11)</span>
</p><p><b><a href="c/thread.html" title="c/thread"> Thread support library</a></b> <span class="t-mark-rev t-since-c11">(C11)</span>
</p>
</td></tr>
<tr class="row">
<td colspan="3"><b><a href="c/experimental.html" title="c/experimental"> Technical specifications</a></b>
<p>  <b><a href="c/experimental/dynamic.html" title="c/experimental/dynamic"> Dynamic memory extensions</a></b>  <span class="t-mark-rev t-since-dynamic-tr t-mark-ts">(dynamic memory TR)</span><br>
  <b><a href="c/experimental/fpext1.html" title="c/experimental/fpext1"> Floating-point extensions, Part 1</a></b>  <span class="t-mark-rev t-since-fpext1-ts t-mark-ts">(FP Ext 1 TS)</span><br>
  <b><a href="c/experimental/fpext4.html" title="c/experimental/fpext4"> Floating-point extensions, Part 4</a></b>  <span class="t-mark-rev t-since-fpext4-ts t-mark-ts">(FP Ext 4 TS)</span><br>
</p>
</td></tr>
<tr class="row rowbottom">
<td colspan="3"> <a href="c/links.html" title="c/links">External Links</a>  −  <a href="c/links/libs.html" title="c/links/libs">Non-ANSI/ISO Libraries</a>  −  <a href="c/index.html" title="c/index" class="mw-redirect">Index</a>  −  <a href="c/index.html" title="c/symbol index">Symbol Index</a>
</td></tr>
</table>
<table class="mainpagetable" cellspacing="0" style="padding: 2em 2em; width: 100%; box-sizing: border-box; -moz-box-sizing: border-box; -webkit-box-sizing: border-box;">

<tr class="row rowtop">
<td> <span style="font-size: 1.5em;">News</span>
</td></tr>
<tr class="row rowbottom">
<td>
<ul><li> 28 October 2018: New version of the <a href="https://en.cppreference.com/w/Cppreference:Archives" title="Cppreference:Archives">offline archive</a>
</li></ul>
<ul><li> 11 March 2018: New version of the <a href="https://en.cppreference.com/w/Cppreference:Archives" title="Cppreference:Archives">offline archive</a>
</li></ul>
<ul><li> 1 December 2017: ISO C++17 published.
</li></ul>
</td></tr></table>

<!-- 
NewPP limit report
Preprocessor visited node count: 1179/1000000
Preprocessor generated node count: 1459/1000000
Post‐expand include size: 19133/2097152 bytes
Template argument size: 3700/2097152 bytes
Highest expansion depth: 8/40
Expensive parser function count: 0/100
-->

<!-- Saved in parser cache with key mwiki1-mwiki_en_:pcache:idhash:1-0!*!0!*!*!*!* and timestamp 20190508081656 -->
</div>                    <!-- /bodycontent -->
                                        <!-- printfooter -->
                    <div class="printfooter">
                    Retrieved from "<a href="https://en.cppreference.com/mwiki/index.php?title=Main_Page&amp;oldid=110059">https://en.cppreference.com/mwiki/index.php?title=Main_Page&amp;oldid=110059</a>"                    </div>
                    <!-- /printfooter -->
                                                            <!-- catlinks -->
                    <!-- /catlinks -->
                                                            <div class="visualClear"></div>
                    <!-- debughtml -->
                                        <!-- /debughtml -->
                </div>
                <!-- /bodyContent -->
            </div>
        </div>
        <!-- /content -->
        <!-- footer -->
        <!-- /footer -->
        <script>if(window.mw){
mw.loader.state({"site":"loading","user":"missing","user.groups":"ready"});
}</script>
<script src="../common/skin_scripts.js"></script>
<script>if(window.mw){
mw.loader.load(["mediawiki.action.view.postEdit","mediawiki.user","mediawiki.page.ready","mediawiki.searchSuggest","mediawiki.hidpi","ext.gadget.ColiruCompiler","ext.gadget.MathJax"], null, true);
}</script>
<script src="../common/site_scripts.js"></script>
<script type="text/javascript">
var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-2828341-1']);
_gaq.push(['_setDomainName', 'cppreference.com']);
_gaq.push(['_trackPageview']);
</script><!-- Served in 0.204 secs. -->
	</body>
<!-- Cached 20190508081656 -->
</html>