import sys
input = sys.stdin.readline
sys.setrecursionlimit(1000000)

n = int(input().strip())
ls = list(map(int, input().strip().split()))
ls.sort()
print(*ls, sep=' ')