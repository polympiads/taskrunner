#include <iostream>
#include <algorithm>
using namespace std;
long long a[10000000];
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    long long n;
    cin>>n;
    for (int i = 0; i < n; i++) cin>>a[i];
    sort(a, a + n);
    for (int i = 0; i < n; i++) cout << a[i] << " ";
    return 0;
}
