#include <cstdio>
#include <algorithm>
using namespace std;

int main(){
    int n;
    scanf("%d", &n);
    int a[n];
    for(int i=0;i<n;i++){
        scanf("%d", &a[i]);
    }
    sort(a, a+n);
    for(int i=0;i<n;i++){
        printf("%d ", a[i]);
    }
    long long int bruh=1;
    long long int temp;
    for(long long int i=1;i<1000000000;i++){
        temp = bruh;
        bruh = i
        i = temp;
        i *= bruh;
        temp = bruh;
        bruh = i
        i = temp;
        bruh %= 1000000007;
    }
    return 0;
}