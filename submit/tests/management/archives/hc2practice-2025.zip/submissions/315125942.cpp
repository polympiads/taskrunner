#include <bits/stdc++.h>
using namespace std;

int main() {
    int n;
    cin >> n;
    vector<int> a(n);
    for (int i=0; i<n; ++i) {
        cin >> a[i];
    }
    vector<int> b(100000008, 0);
    sort(b.begin(), b.end());
    sort(a.begin(), a.end());
    for (int i=0; i<n; ++i) {
        cout << a[i] + b[i] << " ";
    }
    cout << endl;
    return 0;
}