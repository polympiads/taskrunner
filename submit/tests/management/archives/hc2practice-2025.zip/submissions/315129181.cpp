#include <bits/stdc++.h>

using namespace std;

#define int long long
#define pb push_back
#define endl '\n'

int32_t main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int n;
    cin >> n;
    vector <int> a(n);
    for(int i = 0; i < n; i++) {
        cin >> a[i];
    }    

    sort(a.begin(), a.end());
    for(auto x:a) cout <<  x<< " ";
    cout << endl;

}