#include<bits/stdc++.h>
using namespace std;


bool cmp(const int& a, const int &b) {
    return a < b;
}

int main() {

    ios::sync_with_stdio(false);
    cin.tie(0);

    int n;
    cin >> n;

    vector<int> v(n);
    for(int &i : v) cin >> i;

    sort(v.begin(), v.end(), cmp);
    for(int i : v) cout << i << " ";
    return 0;
}